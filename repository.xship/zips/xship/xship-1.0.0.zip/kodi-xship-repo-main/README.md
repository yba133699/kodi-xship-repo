# Xship Kodi Repository

This repository contains the Xship addon for Kodi.

## Installation

1. Download the repository zip file.
2. In Kodi, go to Settings > Add-ons > Install from zip file.
3. Select the downloaded zip file to install the repository.
4. Once the repository is installed, you can install the Xship addon from it
